# ============================================================
# phys_damage: 通常攻撃関連

# roll_critical: 敏捷と基礎確率からクリティカル発生を判定するヘルパー
# _calc_net_hits: 攻撃側/防御側の倍率と命中/回避率から物理攻撃の実効ヒット数を求める
# _calc_base_phys_damage_per_hit: 攻撃力と防御力から1ヒットあたりの物理ダメージ（乱数込み）を算出する
# physical_damage_char_to_enemy: キャラ→敵の物理攻撃ダメージを計算し、必要に応じてクリティカル判定も行う
# _calc_base_phys_damage_per_hit_enemy_to_char: 敵攻撃力とキャラ防御値から、敵→キャラ用の1ヒットあたり物理ダメージを算出する
# physical_damage_enemy_to_char: 敵→キャラの物理ダメージ（Mini/Toad・ブラインド・クリティカル等を考慮）を計算する
# ============================================================

import random
from typing import Optional, overload, Literal

from combat.enums import ElementRelation
from combat.models import (
    FinalCharacterStats,
    FinalEnemyStats,
    BattleActorState,
    AttackResult,
)
from combat.elements import apply_element_relation_to_damage


# ============================================================
# クリティカル判定ヘルパ
# ============================================================


def roll_critical(
    agility: int,
    rng: Optional[random.Random] = None,
    base_chance: float = 1.0 / 16.0,  # 6.25%を基準に
    agi_bonus_div: int = 512,  # Agiが少しずつ効くように
) -> bool:
    """
    クリティカル判定。
    簡易式: base + Agi/agi_bonus_div
    """
    chance = base_chance + agility / agi_bonus_div
    chance = min(max(chance, 0.0), 0.5)  # 上限50%
    if rng is None:
        rng = random.Random()
    return rng.random() < chance


# ============================================================
# 物理ダメージ計算：キャラ → 敵
# ============================================================


def _cap_physical_hit_percent(hit_percent: int) -> int:
    """物理 Hit% は FAQ に合わせて 99 を上限にする。"""
    return max(0, min(hit_percent, 99))


def _calc_net_hits(
    atk_multiplier: int,
    hit_percent: int,
    def_multiplier: int,
    evade_percent: int,
    *,
    rng: Optional[random.Random] = None,
    use_expectation: bool,
) -> float:
    """物理攻撃の実効ヒット数を求める。乱数モードでは FAQ に寄せて 1 ヒットずつ判定する。"""
    h = _cap_physical_hit_percent(hit_percent) / 100.0
    e = max(0, min(evade_percent, 100)) / 100.0

    if use_expectation:
        m = atk_multiplier * h - def_multiplier * e
        return max(m, 0.0)

    if rng is None:
        rng = random.Random()

    attack_hits = sum(1 for _ in range(max(atk_multiplier, 0)) if rng.random() < h)
    evade_hits = sum(1 for _ in range(max(def_multiplier, 0)) if rng.random() < e)
    return float(max(attack_hits - evade_hits, 0))


def _calc_base_phys_damage_per_hit(
    attack_power: int,
    defense: int,
    *,
    rng: Optional[random.Random] = None,
    use_expectation: bool,
) -> int:
    """
    1ヒットあたりの物理ダメージ（乱数込み）
    AttackPower * [1.0, 1.5] - Defense
    FAQ に寄せるため、最低 1 の保証はヒット単位ではなく最終ダメージ段で行う。
    """
    if use_expectation:
        factor = 1.25
    else:
        if rng is None:
            rng = random.Random()
        factor = rng.uniform(1.0, 1.5)
    raw = int(attack_power * factor)
    return raw - defense


def _physical_damage_char_to_target(
    *,
    char: FinalCharacterStats,
    target_defense: int,
    target_def_multiplier: int,
    target_evasion_percent: int,
    attacker_row: str,
    hand: str = "main",
    rng: Optional[random.Random] = None,
    use_expectation: bool = True,
    blind: bool = False,
    attacker_is_mini_or_toad: bool = False,
    attacker_state: Optional[BattleActorState] = None,
) -> AttackResult:
    """キャラ → 任意対象の物理ダメージ共通処理。"""
    if attacker_is_mini_or_toad:
        return AttackResult(damage=0, hit_count=0, is_critical=False)

    if hand == "off":
        atk_power = char.off_power
        atk_mul = char.off_atk_multiplier
        hit_percent = char.off_accuracy
    else:
        atk_power = char.main_power
        atk_mul = char.main_atk_multiplier
        hit_percent = char.main_accuracy

    if attacker_state is not None:
        cheer_bonus = getattr(attacker_state, "cheer_bonus", 0)
        if cheer_bonus > 0:
            atk_power += cheer_bonus

    atk_power += getattr(char, "haste_power_bonus", 0)
    atk_mul = min(16, atk_mul + getattr(char, "haste_multiplier_bonus", 0))

    if atk_power <= 0 or atk_mul <= 0:
        return AttackResult(damage=0, hit_count=0, is_critical=False)

    hit_percent = _cap_physical_hit_percent(hit_percent)
    if blind:
        hit_percent //= 2

    if attacker_row == "back":
        is_long = char.off_long if hand == "off" else char.main_long
        if not is_long:
            hit_percent //= 2

    net_hits = _calc_net_hits(
        atk_multiplier=atk_mul,
        hit_percent=hit_percent,
        def_multiplier=target_def_multiplier,
        evade_percent=target_evasion_percent,
        rng=rng,
        use_expectation=use_expectation,
    )
    hit_count = int(round(net_hits)) if use_expectation else int(net_hits)
    if hit_count <= 0:
        return AttackResult(damage=0, hit_count=0, is_critical=False)

    base_per_hit = _calc_base_phys_damage_per_hit(
        attack_power=atk_power,
        defense=target_defense,
        rng=rng,
        use_expectation=use_expectation,
    )

    dmg = _apply_physical_damage_floor(base_per_hit * net_hits, net_hits)
    dmg = max(dmg, 0)

    is_crit = False
    if not use_expectation:
        if rng is None:
            rng = random.Random()
        if roll_critical(char.agility, rng):
            is_crit = True
            dmg *= 2
            dmg = max(dmg, 0)

    return AttackResult(damage=dmg, hit_count=hit_count, is_critical=is_crit)


@overload
def physical_damage_char_to_enemy(
    char: FinalCharacterStats,
    enemy: FinalEnemyStats,
    hand: str = "main",
    element_relation: ElementRelation = "normal",
    rng: Optional[random.Random] = None,
    use_expectation: bool = True,
    blind: bool = False,
    attacker_is_mini_or_toad: bool = False,
    return_crit: Literal[False] = False,
    attacker_state=None,
    return_hits: Literal[False] = False,
) -> AttackResult: ...


@overload
def physical_damage_char_to_enemy(
    char: FinalCharacterStats,
    enemy: FinalEnemyStats,
    hand: str = "main",
    element_relation: ElementRelation = "normal",
    rng: Optional[random.Random] = None,
    use_expectation: bool = True,
    blind: bool = False,
    attacker_is_mini_or_toad: bool = False,
    return_crit: Literal[True] = True,
    attacker_state=None,
    return_hits: Literal[False] = False,
) -> AttackResult: ...


@overload
def physical_damage_char_to_enemy(
    char: FinalCharacterStats,
    enemy: FinalEnemyStats,
    hand: str = "main",
    element_relation: ElementRelation = "normal",
    rng: Optional[random.Random] = None,
    use_expectation: bool = True,
    blind: bool = False,
    attacker_is_mini_or_toad: bool = False,
    return_crit: Literal[True] = True,
    attacker_state=None,
    return_hits: Literal[True] = True,
) -> AttackResult: ...


def physical_damage_char_to_enemy(
    char: FinalCharacterStats,
    enemy: FinalEnemyStats,
    hand: str = "main",
    element_relation: ElementRelation = "normal",
    rng: Optional[random.Random] = None,
    use_expectation: bool = True,
    blind: bool = False,
    attacker_is_mini_or_toad: bool = False,
    return_crit: bool = False,  # 互換のため残す（使わない）
    attacker_state=None,
    return_hits: bool = False,  # 互換のため残す（使わない）
) -> AttackResult:
    """
    キャラクター → 敵 物理ダメージ（手を指定）。
    戻り値は常に AttackResult に統一する。
      - damage: 与えたダメージ（int）
      - hit_count: 表示用ヒット数（int、ミスは0）
      - is_critical: クリティカルか（期待値モードでは常にFalse）
    """

    result = _physical_damage_char_to_target(
        char=char,
        target_defense=enemy.defense,
        target_def_multiplier=enemy.defense_multiplier,
        target_evasion_percent=enemy.evasion_percent,
        attacker_row=char.row,
        hand=hand,
        rng=rng,
        use_expectation=use_expectation,
        blind=blind,
        attacker_is_mini_or_toad=attacker_is_mini_or_toad,
        attacker_state=attacker_state,
    )
    result.damage = apply_element_relation_to_damage(result.damage, element_relation)
    return result


def physical_damage_char_to_ally(
    char: FinalCharacterStats,
    target: FinalCharacterStats,
    hand: str = "main",
    rng: Optional[random.Random] = None,
    use_expectation: bool = True,
    blind: bool = False,
    attacker_is_mini_or_toad: bool = False,
    attacker_state: Optional[BattleActorState] = None,
) -> AttackResult:
    """
    キャラクター → 味方/自分 の物理ダメージ。
    FAQ の self-targetting に合わせて Defense は 0 扱いにする。
    """
    return _physical_damage_char_to_target(
        char=char,
        target_defense=0,
        target_def_multiplier=target.defense_multiplier,
        target_evasion_percent=target.evasion_percent,
        attacker_row=char.row,
        hand=hand,
        rng=rng,
        use_expectation=use_expectation,
        blind=blind,
        attacker_is_mini_or_toad=attacker_is_mini_or_toad,
        attacker_state=attacker_state,
    )


# ============================================================
# 物理ダメージ計算：敵 → キャラ
# ============================================================


def _apply_physical_damage_floor(damage: float | int, net_hits: float) -> int:
    """FAQ に寄せた物理ダメージ下限。ヒット成立時のみ最終 1 を保証する。"""
    if net_hits <= 0:
        return 0
    return max(int(damage), 1)


def _calc_base_phys_damage_per_hit_enemy_to_char(
    enemy: FinalEnemyStats,
    defense_value: int,
    *,
    rng: Optional[random.Random] = None,
    use_expectation: bool,
) -> int:
    if use_expectation:
        factor = 1.25
    else:
        if rng is None:
            rng = random.Random()
        factor = rng.uniform(1.0, 1.5)
    attack_power = enemy.attack_power + getattr(enemy, "haste_power_bonus", 0)
    raw = int(attack_power * factor)
    return raw - defense_value


@overload
def physical_damage_enemy_to_char(
    enemy: FinalEnemyStats,
    char: FinalCharacterStats,
    rng: Optional[random.Random] = None,
    use_expectation: bool = True,
    attacker_is_blind: bool = False,
    attacker_is_mini_or_toad: bool = False,
    target_is_mini_or_toad: bool = False,
    return_crit: Literal[False] = False,
    target_state: Optional[BattleActorState] = None,
) -> int: ...


@overload
def physical_damage_enemy_to_char(
    enemy: FinalEnemyStats,
    char: FinalCharacterStats,
    rng: Optional[random.Random] = None,
    use_expectation: bool = True,
    attacker_is_blind: bool = False,
    attacker_is_mini_or_toad: bool = False,
    target_is_mini_or_toad: bool = False,
    return_crit: Literal[True] = True,
    target_state: Optional[BattleActorState] = None,
) -> tuple[int, bool, float]: ...


def physical_damage_enemy_to_char(
    enemy: FinalEnemyStats,
    char: FinalCharacterStats,
    rng: Optional[random.Random] = None,
    use_expectation: bool = True,
    attacker_is_blind: bool = False,
    attacker_is_mini_or_toad: bool = False,
    target_is_mini_or_toad: bool = False,
    return_crit: bool = False,
    target_state: Optional[BattleActorState] = None,
) -> int | tuple[int, bool] | tuple[int, bool, float]:
    """
    敵 → キャラの物理ダメージ
    return_crit=True のとき (dmg, is_crit, net_hits) を返す
    """

    if attacker_is_mini_or_toad:
        return (0, False, 0) if return_crit else 0

    defense_value = char.defense
    def_mul = char.defense_multiplier
    evade_percent = char.evasion_percent

    if target_is_mini_or_toad:
        defense_value = 0

    if target_state is not None:
        if getattr(target_state, "boost_count", 0) > 0:
            defense_value = 0
            def_mul = 0

    hit_percent = _cap_physical_hit_percent(enemy.accuracy_percent)
    attack_multiplier = min(
        16, enemy.attack_multiplier + getattr(enemy, "haste_multiplier_bonus", 0)
    )
    if attacker_is_blind:
        hit_percent //= 2

    # ★後列ペナルティ：後列を狙う物理攻撃は Hit% 半減
    if char.row == "back":
        hit_percent //= 2

    net_hits = _calc_net_hits(
        atk_multiplier=attack_multiplier,
        hit_percent=hit_percent,
        def_multiplier=def_mul,
        evade_percent=evade_percent,
        rng=rng,
        use_expectation=use_expectation,
    )
    if net_hits <= 0:
        return (0, False, 0) if return_crit else 0

    base_per_hit = _calc_base_phys_damage_per_hit_enemy_to_char(
        enemy=enemy,
        defense_value=defense_value,
        rng=rng,
        use_expectation=use_expectation,
    )

    dmg = _apply_physical_damage_floor(base_per_hit * net_hits, net_hits)
    is_crit = False
    if not use_expectation:
        if rng is None:
            rng = random.Random()
        if roll_critical(enemy.level, rng, base_chance=1 / 20, agi_bonus_div=9999):
            is_crit = True
            dmg *= 2

    dmg = max(int(dmg), 0)

    return (dmg, is_crit, net_hits) if return_crit else dmg
