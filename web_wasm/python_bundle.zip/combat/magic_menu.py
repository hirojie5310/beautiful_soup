# ============================================================
# magic_menu: メニュー生成まわり

# build_party_magic_lists	キャラごとのジョブで使える魔法一覧生成
# build_party_magic_info	パーティのジョブ名、使用できる魔法リスト等を生成
# build_magic_list	ジョブが使える魔法名(魔法名,種別,レベル)のリストにして整列して返す
# allowed_spell_names_for_job	ffiii_jobs_compact.jsonのjob.raw["Spells"]を正とし、
# print_magic_menu_by_level	魔法をLv単位で1行形式で表示する
# expand_spells_for_summons	spells.json内のSummonMagic（親：Bahamut等）を、子召喚魔法へ展開する
# ============================================================

from typing import Optional, Dict, Any, Tuple, List, Iterable
from collections import defaultdict

from combat.constants import JOB_CAST_CODE
from combat.models import (
    Job,
    BattleActorState,
    PartyMagicInfo,
    MagicCandidate,
    MagicType,
)

MAGIC_SLOT_COUNT = 3


def _level_key(level: int) -> str:
    return f"LV{max(1, min(8, int(level)))}"


def _find_magic_container(data: Dict[str, Any]) -> Dict[str, Any]:
    for key in ("magic", "Magic"):
        value = data.get(key)
        if isinstance(value, dict):
            return value
    return {}


def load_equipped_magic_slots_from_entry(
    party_entry: Dict[str, Any],
) -> Dict[int, List[Optional[str]]]:
    raw_magic = _find_magic_container(party_entry)
    out: Dict[int, List[Optional[str]]] = {
        lv: [None] * MAGIC_SLOT_COUNT for lv in range(1, 9)
    }
    for lv in range(1, 9):
        raw_row = raw_magic.get(_level_key(lv))
        row = out[lv]
        if isinstance(raw_row, list):
            for idx, spell_name in enumerate(raw_row[:MAGIC_SLOT_COUNT]):
                if isinstance(spell_name, str) and spell_name:
                    row[idx] = spell_name
            continue
        if isinstance(raw_row, dict):
            for spell_name, slot_no in raw_row.items():
                if not isinstance(spell_name, str) or not spell_name:
                    continue
                try:
                    idx = int(slot_no) - 1
                except (TypeError, ValueError):
                    continue
                if 0 <= idx < MAGIC_SLOT_COUNT:
                    row[idx] = spell_name
    return out


def dump_equipped_magic_slots_to_entry(
    party_entry: Dict[str, Any],
    slots_by_level: Dict[int, List[Optional[str]]],
) -> None:
    raw_magic: Dict[str, List[Optional[str]]] = {}
    for lv in range(1, 9):
        row = list(slots_by_level.get(lv, [None] * MAGIC_SLOT_COUNT))[:MAGIC_SLOT_COUNT]
        normalized_row: List[Optional[str]] = [
            spell_name if isinstance(spell_name, str) and spell_name else None
            for spell_name in row
        ]
        while len(normalized_row) < MAGIC_SLOT_COUNT:
            normalized_row.append(None)
        raw_magic[_level_key(lv)] = normalized_row
    party_entry["Magic"] = raw_magic
    party_entry.pop("magic", None)


def load_party_inventory_magic_counts(
    save: Dict[str, Any],
) -> Dict[int, Dict[str, int]]:
    inventory = save.get("inventory", {}) if isinstance(save, dict) else {}
    raw_magic = _find_magic_container(inventory) if isinstance(inventory, dict) else {}
    out: Dict[int, Dict[str, int]] = {lv: {} for lv in range(1, 9)}
    for lv in range(1, 9):
        raw_row = raw_magic.get(_level_key(lv), {})
        if not isinstance(raw_row, dict):
            continue
        for spell_name, count in raw_row.items():
            if not isinstance(spell_name, str) or not spell_name:
                continue
            try:
                qty = int(count)
            except (TypeError, ValueError):
                continue
            if qty > 0:
                out[lv][spell_name] = qty
    return out


def build_magic_stock_by_level(
    save: Dict[str, Any],
    spell_meta_by_name: Dict[str, Dict[str, Any]],
) -> Dict[str, List[str]]:
    counts = load_party_inventory_magic_counts(save)
    party = save.get("party", []) if isinstance(save, dict) else []
    for entry in party:
        if not isinstance(entry, dict):
            continue
        for lv, row in load_equipped_magic_slots_from_entry(entry).items():
            for spell_name in row:
                if isinstance(spell_name, str) and spell_name:
                    remain = counts.get(lv, {}).get(spell_name, 0)
                    if remain > 0:
                        counts[lv][spell_name] = remain - 1

    type_order = {"Black Magic": 0, "White Magic": 1, "Summon Magic": 2}
    stock_by_level: Dict[str, List[str]] = {}
    for lv in range(1, 9):
        expanded: List[tuple[int, str]] = []
        for spell_name, qty in counts.get(lv, {}).items():
            magic_type = str(spell_meta_by_name.get(spell_name, {}).get("type") or "")
            expanded.extend(
                [(type_order.get(magic_type, 99), spell_name)] * max(0, qty)
            )
        expanded.sort(key=lambda row: (row[0], row[1]))
        stock_by_level[str(lv)] = [name for _, name in expanded]
    return stock_by_level


# party_entry からジョブ名を取得（揺れ対策）
def get_job_name_from_party_entry(party_entry: Dict[str, Any]) -> str:
    job_name = party_entry.get("job") or party_entry.get("job_level", {}).get("job")
    if not isinstance(job_name, str) or not job_name:
        raise KeyError("party_entry に job が見つかりません")
    return job_name


def _normalize_cast_codes(raw_cast_by: Any) -> list[str]:
    if not raw_cast_by:
        return []
    if isinstance(raw_cast_by, str):
        return [part.strip() for part in raw_cast_by.split(",") if part.strip()]
    if isinstance(raw_cast_by, list):
        return [str(part).strip() for part in raw_cast_by if str(part).strip()]
    return []


def resolve_summon_spell_names_for_cast_code(
    *,
    spell_name: str,
    spells_by_name: Dict[str, Dict[str, Any]],
    cast_code: Optional[str],
    allowed_names: Optional[Iterable[str]] = None,
) -> list[str]:
    """
    固定スロットに保存されている召喚魔法の親名（例: Shiva）から、
    そのジョブ/キャストコードで実際に使える子スペル名を返す。

    - 黒/白など通常魔法はそのまま [spell_name]
    - 召喚親なら cast_by と allowed_names を使って子へ解決
    - Evoker のように複数候補がある場合は複数返す
    """
    spell_def = spells_by_name.get(spell_name)
    if isinstance(spell_def, dict):
        parent_name = spell_def.get("parent_spell_name")
        if isinstance(parent_name, str) and parent_name:
            parent_spell = spells_by_name.get(parent_name)
            if isinstance(parent_spell, dict):
                spell_name = parent_name
            else:
                return [spell_name]
        else:
            parent_spell = spell_def
    else:
        parent_spell = None
        sibling_names = [
            name
            for name, raw in spells_by_name.items()
            if isinstance(raw, dict) and raw.get("parent_spell_name") == spell_name
        ]
        if sibling_names:
            resolved = []
            for sibling_name in sibling_names:
                sibling_def = spells_by_name.get(sibling_name) or {}
                if not isinstance(sibling_def, dict):
                    continue
                if allowed_names is not None and sibling_name not in set(allowed_names):
                    continue
                child_cast_codes = _normalize_cast_codes(sibling_def.get("cast_by"))
                if cast_code and child_cast_codes and cast_code not in child_cast_codes:
                    continue
                resolved.append(sibling_name)
            if resolved:
                return resolved

    if isinstance(parent_spell, dict):
        if str(parent_spell.get("Type") or "").strip() != "Summon Magic":
            return [spell_name]
    else:
        return [spell_name]

    if not isinstance(parent_spell, dict):
        return []

    allowed_set = set(allowed_names) if allowed_names is not None else None
    resolved: list[str] = []
    for child in parent_spell.get("Spells") or []:
        if not isinstance(child, dict):
            continue
        child_name = child.get("name") or child.get("Name")
        if not isinstance(child_name, str) or not child_name:
            continue
        if allowed_set is not None and child_name not in allowed_set:
            continue
        child_cast_codes = _normalize_cast_codes(child.get("cast_by"))
        if cast_code and child_cast_codes and cast_code not in child_cast_codes:
            continue
        resolved.append(child_name)
    return resolved


def resolve_equipped_spell_names_for_job(
    *,
    equipped_names: Iterable[str],
    spells_by_name: Dict[str, Dict[str, Any]],
    cast_code: Optional[str],
    allowed_names: Optional[Iterable[str]] = None,
) -> list[str]:
    resolved: list[str] = []
    for spell_name in equipped_names:
        names = resolve_summon_spell_names_for_cast_code(
            spell_name=spell_name,
            spells_by_name=spells_by_name,
            cast_code=cast_code,
            allowed_names=allowed_names,
        )
        if names:
            resolved.extend(names)
            continue
        resolved.append(spell_name)
    return resolved


def _magic_candidate_from_spell_name(
    *,
    spell_name: str,
    spells_by_name: Dict[str, Dict[str, Any]],
    allowed_lookup: Dict[str, MagicCandidate],
) -> Optional[MagicCandidate]:
    candidate = allowed_lookup.get(spell_name)
    if candidate is not None:
        return candidate

    spell_json = spells_by_name.get(spell_name)
    if not isinstance(spell_json, dict):
        return None

    spell_type = str(spell_json.get("Type") or "").strip()
    if spell_type != "Summon Magic":
        return None

    level = int(spell_json.get("Level", 0) or 0)
    return (spell_name, MagicType.SUMMON, level)


def _build_equipped_magic_candidates(
    *,
    equipped_names: Iterable[str],
    spells_by_name: Dict[str, Dict[str, Any]],
    cast_code: Optional[str],
    allowed_names: Optional[Iterable[str]],
    allowed_lookup: Dict[str, MagicCandidate],
) -> list[MagicCandidate]:
    candidates: list[MagicCandidate] = []
    allowed_set = set(allowed_names) if allowed_names is not None else None
    for spell_name in equipped_names:
        resolved_names = resolve_summon_spell_names_for_cast_code(
            spell_name=spell_name,
            spells_by_name=spells_by_name,
            cast_code=cast_code,
            allowed_names=allowed_names,
        )
        if not resolved_names:
            if allowed_set is not None and spell_name in allowed_set:
                candidate_name = spell_name
            else:
                continue
        elif len(resolved_names) == 1:
            candidate_name = resolved_names[0]
        else:
            # Evoker 系の複数分岐召喚は、NES版に寄せて親名を 1 件だけ表示する。
            candidate_name = spell_name

        candidate = _magic_candidate_from_spell_name(
            spell_name=candidate_name,
            spells_by_name=spells_by_name,
            allowed_lookup=allowed_lookup,
        )
        if candidate is not None:
            candidates.append(candidate)
    return candidates


# キャラごとのジョブで使える魔法一覧生成（薄いラッパ）
def build_party_magic_lists(state) -> List[List[MagicCandidate]]:
    return build_party_magic_lists_from_party(
        party_entries=state.save["party"],
        jobs_by_name=state.jobs_by_name,
        spells_by_name=state.spells,
        job_cast_code=JOB_CAST_CODE,
    )


# キャラごとのジョブで使える魔法一覧生成
def build_party_magic_lists_from_party(
    *,
    party_entries: List[Dict[str, Any]],
    jobs_by_name: Dict[str, Any],  # Job型でもOK
    spells_by_name: Dict[str, Dict[str, Any]],  # expand後でもexpand前でもOK
    job_cast_code: Dict[str, str],  # = JOB_CAST_CODE
) -> List[List[MagicCandidate]]:
    spells_expanded = expand_spells_for_summons(spells_by_name)

    out: List[List[MagicCandidate]] = []

    for entry in party_entries:
        job_name = get_job_name_from_party_entry(entry)

        try:
            job_data = jobs_by_name[job_name]
        except KeyError as e:
            raise KeyError(f"jobs_by_name に '{job_name}' が存在しません") from e

        cast_code = job_cast_code.get(job_name)
        allowed_names = allowed_spell_names_for_job(job_data)

        allowed_magic_list = build_magic_list(
            spells_expanded,
            allowed_names=allowed_names,
            cast_code=cast_code,
        )
        equipped_slots = load_equipped_magic_slots_from_entry(entry)
        equipped_names = [
            spell_name
            for lv in range(1, 9)
            for spell_name in equipped_slots[lv]
            if isinstance(spell_name, str) and spell_name
        ]
        if not equipped_names:
            out.append(allowed_magic_list)
            continue

        allowed_lookup = {
            name: (name, magic_type, level)
            for name, magic_type, level in allowed_magic_list
        }
        out.append(
            _build_equipped_magic_candidates(
                equipped_names=equipped_names,
                spells_by_name=spells_by_name,
                cast_code=cast_code,
                allowed_names=allowed_names,
                allowed_lookup=allowed_lookup,
            )
        )

    # print(f"[DBG build_party_magic_lists_from_party]{out}")
    return out


# パーティのジョブ名、使用できる魔法リスト等を生成（薄いラッパ）
def build_party_magic_info(state) -> List[PartyMagicInfo]:
    return build_party_magic_info_from_party(
        party_entries=state.save["party"],
        jobs_by_name=state.jobs_by_name,
        spells_by_name=state.spells,
        job_cast_code=JOB_CAST_CODE,
    )


# パーティのジョブ名、使用できる魔法リスト等を生成
def build_party_magic_info_from_party(
    *,
    party_entries: List[Dict[str, Any]],
    jobs_by_name: Dict[str, Any],
    spells_by_name: Dict[str, Dict[str, Any]],
    job_cast_code: Dict[str, str],
) -> List[PartyMagicInfo]:
    spells_expanded = expand_spells_for_summons(spells_by_name)

    out: List[PartyMagicInfo] = []

    for entry in party_entries:
        job_name = get_job_name_from_party_entry(entry)

        try:
            job_data = jobs_by_name[job_name]
        except KeyError as e:
            raise KeyError(f"jobs_by_name に '{job_name}' が存在しません") from e

        cast_code = job_cast_code.get(job_name)
        allowed_names = allowed_spell_names_for_job(job_data)

        allowed_magic_list = build_magic_list(
            spells_expanded,
            allowed_names=allowed_names,
            cast_code=cast_code,
        )
        magic_list = allowed_magic_list
        equipped_slots = load_equipped_magic_slots_from_entry(entry)
        equipped_names = [
            spell_name
            for lv in range(1, 9)
            for spell_name in equipped_slots[lv]
            if isinstance(spell_name, str) and spell_name
        ]
        if equipped_names:
            allowed_lookup = {
                name: (name, magic_type, level)
                for name, magic_type, level in allowed_magic_list
            }
            magic_list = _build_equipped_magic_candidates(
                equipped_names=equipped_names,
                spells_by_name=spells_by_name,
                cast_code=cast_code,
                allowed_names=allowed_names,
                allowed_lookup=allowed_lookup,
            )

        out.append(
            PartyMagicInfo(
                job_name=job_name,
                cast_code=cast_code,
                allowed_names=allowed_names,
                magic_list=magic_list,
            )
        )

    return out


# --- ここから追加: 魔法一覧と選択メニュー ---
def build_magic_list(
    spells_by_name: Dict[str, Dict[str, Any]],
    *,
    allowed_names: Optional[Iterable[str]] = None,
    cast_code: Optional[str] = None,
) -> List[MagicCandidate]:

    allowed_set = set(allowed_names) if allowed_names is not None else None

    lst: List[MagicCandidate] = []
    for name, s in spells_by_name.items():

        if allowed_set is not None and name not in allowed_set:
            continue

        if cast_code is not None:
            cast_by = s.get("cast_by")
            if cast_by:
                if isinstance(cast_by, str):
                    ok = cast_code in [c.strip() for c in cast_by.split(",")]
                elif isinstance(cast_by, list):
                    ok = cast_code in cast_by
                else:
                    ok = False
                if not ok:
                    continue

        t_raw = s.get("Type", "")
        if t_raw not in ("Black Magic", "White Magic", "Summon Magic", "Summon"):
            continue

        level = int(s.get("Level", 0) or 0)

        # 子召喚(Type="Summon")は Summon Magic に寄せる
        t_raw = "Summon Magic" if t_raw == "Summon" else t_raw

        # ★ ここで Enum 化（境界変換）
        try:
            t_norm = MagicType(t_raw)
        except ValueError:
            continue

        lst.append((name, t_norm, level))

    type_order = {"Black Magic": 0, "White Magic": 1, "Summon Magic": 2}
    lst.sort(key=lambda x: (type_order.get(x[1], 99), x[2], x[0]))
    return lst


# ============================================================
# ジョブ別の魔法使用制限ヘルパー
# ============================================================


def allowed_spell_names_for_job(job: Job) -> set[str]:
    """
    ffiii_jobs_compact.json の job.raw["Spells"] を正とし、
    そのジョブが使用可能な魔法名の集合を返す。
    """
    spells = job.raw.get("Spells") or []
    return {
        s.get("name") or s.get("Name")
        for s in spells
        if s.get("name") or s.get("Name")
    }


# レベル別・黒白まとめ表示関数
def print_magic_menu_by_level(
    magic_list: List[Tuple[str, str, int]],
    char_state: BattleActorState,
):
    """
    魔法を Lv 単位で 1 行形式で表示する。
    例:
      Lv1 (3/9): (Black) 1: Blizzard, 2: Fire (White) 13: Cure, 14: Poisona
    """
    bucket = defaultdict(lambda: defaultdict(list))

    for idx, (name, mtype, lvl) in enumerate(magic_list, start=1):
        bucket[lvl][mtype].append((idx, name))

    type_label = {
        "Black Magic": "Black",
        "White Magic": "White",
        "Summon Magic": "Summon",
    }

    for lvl in sorted(bucket.keys()):
        remain = char_state.mp_pool.get(lvl, 0)
        maxmp = char_state.max_mp_pool.get(lvl, remain)

        # --- 行頭（LvX (a/b): ）
        line = f"Lv{lvl} ({remain}/{maxmp}): "

        parts = []
        for mtype in ("Black Magic", "White Magic", "Summon Magic"):
            if mtype not in bucket[lvl]:
                continue
            spells = bucket[lvl][mtype]
            s = ", ".join([f"{i}: {nm}" for i, nm in spells])
            parts.append(f"({type_label.get(mtype, mtype)}) {s}")

        # --- 1行でまとめて出力 ---
        line += " ".join(parts)
        print(line)


def expand_spells_for_summons(
    spells_by_name: Dict[str, Dict[str, Any]],
) -> Dict[str, Dict[str, Any]]:
    """
    spells.json 内の Summon Magic（親：Bahamut等）を、
    実戦で使う「子召喚魔法（Bahamut: Mega Flare等）」へ展開する。

    - 親(Type="Summon Magic" かつ Spellsを持つ) → 子を展開
    - すでに展開済みの子（Spellsを持たない Summon Magic）はそのまま残す
    - 子には Power/Accuracy/Element 等を保持させる
    - 子の Type は "Summon" にする（spell_from_json が子分岐に入るため）
    """
    expanded: Dict[str, Dict[str, Any]] = {}

    for name, s in spells_by_name.items():
        raw_type = str(s.get("Type", "")).strip()
        child_list = s.get("Spells")

        # --- 親 Summon Magic（子配列を持つもの）だけ展開 ---
        if raw_type == "Summon Magic" and isinstance(child_list, list) and child_list:
            for child in child_list:
                child_name = child.get("name") or child.get("Name")
                if not child_name:
                    continue

                # 子の中身を基本そのまま使う（Power等を保持）
                new_child = dict(child)
                new_child["Type"] = "Summon"  # ★ここ重要
                new_child["parent_spell_name"] = name

                expanded[child_name] = new_child

        else:
            # 召喚親ではない or すでに子として展開済み → そのまま採用
            expanded[name] = s

    return expanded
